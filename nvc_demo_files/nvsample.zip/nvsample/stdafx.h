// stdafx.h : Includedatei f�r Standardsystem-Includedateien,
// oder projektspezifische Includedateien, die h�ufig benutzt, aber
// in unregelm��igen Abst�nden ge�ndert werden.
//

#pragma once
#include <windows.h>
#include <stdio.h>
#include <sys/stat.h>
#include <io.h>
#include <fcntl.h>

